package com.familyguard.admin;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.time.LocalDate;
import org.junit.jupiter.api.Test;

/** Vigencia por fechas de la restricción de aplicaciones en el Administrador. */
class RestrictionPlanTests {
    private static final LocalDate TODAY = LocalDate.of(2026, 11, 19);

    @Test
    void textosDeVigencia() {
        assertEquals("Siempre", RestrictionPlan.validity(null, null));
        assertEquals("Del 19/11/2026 al 25/11/2026", RestrictionPlan.validity(TODAY, TODAY.plusDays(6)));
        assertEquals("Solo el 19/11/2026", RestrictionPlan.validity(TODAY, TODAY));
        assertEquals("Hasta el 25/11/2026", RestrictionPlan.validity(null, TODAY.plusDays(6)));
    }

    @Test
    void validaLasFechasAntesDeGuardar() {
        assertNull(RestrictionPlan.validate(TODAY, TODAY.plusDays(6), TODAY));
        assertNull(RestrictionPlan.validate(TODAY, TODAY, TODAY));
        assertEquals("La fecha de fin no puede ser anterior a la de inicio.", RestrictionPlan.validate(TODAY.plusDays(3), TODAY, TODAY));
        assertEquals("La fecha de fin ya pasó.", RestrictionPlan.validate(TODAY.minusDays(9), TODAY.minusDays(2), TODAY));
        assertEquals("Elige la fecha de inicio y la de fin.", RestrictionPlan.validate(null, TODAY, TODAY));
    }
}
