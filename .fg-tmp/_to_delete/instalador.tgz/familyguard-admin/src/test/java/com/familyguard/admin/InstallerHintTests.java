package com.familyguard.admin;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import org.junit.jupiter.api.Test;

/** Bloquear el instalador no bloquea el juego: se avisa y se sugiere el ejecutable real. */
class InstallerHintTests {
    @Test
    void reconoceInstaladores() {
        assertTrue(InstallerHint.isInstaller("Modern Combat 5 Installer.exe", "C:\\Users\\Luz\\Downloads\\Modern Combat 5 Installer.exe"));
        assertTrue(InstallerHint.isInstaller("Juego", "C:\\Games\\Juego\\unins000.exe"));
        assertTrue(InstallerHint.isInstaller("setup.exe", null));
        assertFalse(InstallerHint.isInstaller("Google Chrome", "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe"));
        assertFalse(InstallerHint.isInstaller("ModernCombat5.exe", "C:\\Program Files\\WindowsApps\\Gameloft\\ModernCombat5.exe"));
    }

    @Test
    void sugiereElEjecutableDelJuego() {
        var related = InstallerHint.related("Modern Combat 5 Installer.exe",
                List.of("ModernCombat5.exe", "Modern Combat 5", "chrome.exe", "Modern Combat 5 Installer.exe", "explorer.exe"));
        assertEquals(List.of("ModernCombat5.exe", "Modern Combat 5"), related);
        assertEquals(List.of(), InstallerHint.related("setup.exe", List.of("chrome.exe")));
    }
}
