package com.familyguard.agent;

import java.util.Locale;

/**
 * Comparación de ejecutables para las reglas. Las apps y juegos de la Microsoft Store viven en
 * {@code C:\Program Files\WindowsApps\<Nombre>_<Versión>_<Arquitectura>__<Editor>\…}: al actualizarse cambia la carpeta de
 * versión, así que para ellas se compara el nombre del paquete, el editor y el ejecutable, no la versión.
 */
final class ExecutablePaths {
    private static final String STORE = "\\windowsapps\\";
    private ExecutablePaths() { }

    static boolean same(String a, String b) {
        if (a == null || b == null || a.isBlank() || b.isBlank()) return false;
        String x = normalize(a), y = normalize(b);
        if (x.equals(y)) return true;
        String kx = storeKey(x), ky = storeKey(y);
        return kx != null && kx.equals(ky);
    }

    static boolean isStoreApp(String path) { return path != null && normalize(path).contains(STORE); }

    /** «gameloft.moderncombat5__abc123\moderncombat5.exe» o {@code null} si no es una app de la Store. */
    static String storeKey(String normalizedPath) {
        int at = normalizedPath.indexOf(STORE);
        if (at < 0) return null;
        String rest = normalizedPath.substring(at + STORE.length());
        int slash = rest.indexOf('\\');
        if (slash <= 0) return null;
        String folder = rest.substring(0, slash), inside = rest.substring(slash + 1);
        int first = folder.indexOf('_'), publisher = folder.lastIndexOf("__");
        if (first <= 0 || publisher < first) return null;
        return folder.substring(0, first) + folder.substring(publisher) + "\\" + inside;
    }

    private static String normalize(String path) {
        String p = path.strip().replace('/', '\\').toLowerCase(Locale.ROOT);
        while (p.contains("\\\\")) p = p.replace("\\\\", "\\");
        return p;
    }
}
